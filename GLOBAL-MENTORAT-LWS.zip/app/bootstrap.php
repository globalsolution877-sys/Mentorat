<?php
declare(strict_types=1);
$configFile = dirname(__DIR__) . '/config.local.php';
$config = is_file($configFile) ? require $configFile : [];
if (!is_array($config)) $config = [];
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params(['httponly'=>true, 'secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'samesite'=>'Lax', 'path'=>'/']);
    session_start();
}
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
function db(): PDO {
    global $config; static $pdo;
    if (!$pdo) {
        if (empty($config['db_host']) || empty($config['db_name']) || empty($config['db_user']) || empty($config['db_password'])) throw new RuntimeException('Base Supabase non configurée');
        // Les paramètres viennent uniquement du fichier local, jamais des requêtes web.
        $dsn='pgsql:host='.$config['db_host'].';port='.($config['db_port'] ?? 5432).';dbname='.$config['db_name'].';sslmode=verify-full';
        if (!empty($config['db_sslrootcert'])) $dsn.=';sslrootcert='.$config['db_sslrootcert'];
        $pdo = new PDO($dsn, $config['db_user'], $config['db_password'], [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES=>false]);
    }
    return $pdo;
}
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function url(string $page='accueil', array $params=[]): string { global $config; return ($config['base_path'] ?? '').'/index.php?'.http_build_query(['page'=>$page]+$params); }
function asset(string $name): string { global $config; return ($config['base_path'] ?? '').'/assets/'.$name; }
function redirect(string $page, array $params=[]): void { header('Location: '.url($page,$params)); exit; }
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function check_csrf(): void { if (!isset($_POST['csrf']) || !is_string($_POST['csrf']) || !hash_equals(csrf(),$_POST['csrf'])) { http_response_code(403); exit('Session expirée. Rechargez la page.'); } }
function field(string $key, int $limit=5000): string { return mb_substr(trim(is_string($_POST[$key]??null)?$_POST[$key]:''),0,$limit,'UTF-8'); }
require_once __DIR__.'/auth_client.php';
require_once __DIR__.'/auth.php';
function user(): ?array {
    static $checked=false, $current=null;
    if ($checked) return $current;
    $checked=true;
    if (empty($_SESSION['auth']['access_token'])) return null;
    try {
        $identity=auth_session_identity();
        if (!$identity) return null;
        $s=db()->prepare('SELECT id,name,email,role FROM gm_app.users WHERE auth_user_id=?');
        $s->execute([$identity['id']]);
        $current=$s->fetch() ?: null;
    } catch (Throwable $e) { error_log('Vérification de session indisponible.'); return null; }
    return $current;
}
function logged(): void { if (!user()) redirect('connexion'); }
function role_allows(string $type): bool {
    $role=user()['role']??'';
    $roles=['super_admin'=>['*'],'admin'=>['*'],'scholarship_manager'=>['bourse'],'editor'=>['pays','universite','formation','opportunite','article','temoignage','entrepreneuriat']];
    return isset($roles[$role]) && (in_array('*',$roles[$role],true) || in_array($type,$roles[$role],true));
}
function require_staff(): void { logged(); if ((user()['role']??'student')==='student') { http_response_code(403); exit('Accès interdit'); } }
function audit(string $action): void { $s=db()->prepare('INSERT INTO gm_app.audit_log (user_id,action) VALUES (?,?)'); $s->execute([user()['id'],$action]); }
function flash(string $message): void { $_SESSION['flash']=$message; }
function types(): array { return ['bourse'=>'Bourses d’études','pays'=>'Pays de destination','universite'=>'Universités','formation'=>'Formations et filières','opportunite'=>'Opportunités professionnelles','article'=>'Conseils et actualités','temoignage'=>'Témoignages','entrepreneuriat'=>'Entrepreneuriat']; }
