<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') return;
check_csrf();
$action=field('action',40);
try {
    if ($action==='inquiry') {
        $kind=field('kind',30); $email=field('email',190); $name=field('name',120); $message=field('message',5000);
        if (!in_array($kind,['contact','orientation','rendezvous','newsletter'],true) || !filter_var($email,FILTER_VALIDATE_EMAIL) || empty($_POST['consent']) || !empty($_POST['website']) || ($kind!=='newsletter' && (!$name || !$message))) throw new RuntimeException('Vérifiez les champs et le consentement.');
        $s=db()->prepare('INSERT INTO gm_app.inquiries (kind,name,email,phone,message,consent_at) VALUES (?,?,?,?,?,NOW())');
        $s->execute([$kind,$name,$email,field('phone',40),$message]); flash('Votre demande a bien été enregistrée.'); redirect($kind==='newsletter'?'accueil':'contact');
    }
    if ($action==='register') {
        $name=field('name',120); $email=strtolower(field('email',190)); $password=is_string($_POST['password']??null) ? $_POST['password'] : '';
        if (strlen($password)>200) throw new RuntimeException('Mot de passe trop long.');
        if (!$name || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<12 || empty($_POST['consent'])) throw new RuntimeException('Vérifiez les champs. Le mot de passe doit comporter au moins 12 caractères.');
        db(); // Ne pas créer de compte distant si le portail ne peut pas atteindre sa base.
        $result=auth_request('POST','signup',['email'=>$email,'password'=>$password,'data'=>['full_name'=>$name]]);
        if ($result['status']===429) throw new RuntimeException('Trop de tentatives. Réessayez plus tard.');
        if ($result['status']<200 || $result['status']>=300) throw new RuntimeException('Inscription impossible. Vérifiez les informations saisies ou réessayez plus tard.');
        // Ne pas utiliser de jeton retourné à l'inscription ; la connexion est explicite.
        flash('Si votre inscription est acceptée, vérifiez votre e-mail de confirmation, puis connectez-vous.'); redirect('connexion');
    }
    if ($action==='login') {
        $email=strtolower(field('email',190)); $pass=is_string($_POST['password']??null) ? $_POST['password'] : '';
        if (strlen($pass)>200) throw new RuntimeException('Identifiants incorrects.');
        if (!filter_var($email,FILTER_VALIDATE_EMAIL) || !$pass) throw new RuntimeException('Identifiants incorrects.');
        $u=auth_login($email,$pass);
        redirect($u['role']==='student'?'espace':'admin');
    }
    if ($action==='logout') { auth_logout(); redirect(); }
    if ($action==='profile') {
        logged(); $s=db()->prepare('INSERT INTO gm_app.profiles (user_id,academic_profile,diplomas,results,interests) VALUES (?,?,?,?,?) ON CONFLICT (user_id) DO UPDATE SET academic_profile=EXCLUDED.academic_profile,diplomas=EXCLUDED.diplomas,results=EXCLUDED.results,interests=EXCLUDED.interests');
        $s->execute([user()['id'],field('academic_profile'),field('diplomas'),field('results'),field('interests')]); flash('Profil enregistré.'); redirect('espace');
    }
    if ($action==='favorite') {
        logged(); $id=(int)($_POST['id']??0); $s=db()->prepare("SELECT id FROM gm_app.publications WHERE id=? AND type='bourse' AND status='published'"); $s->execute([$id]); if (!$s->fetch()) throw new RuntimeException('Bourse introuvable.');
        $s=db()->prepare('SELECT 1 FROM gm_app.favorites WHERE user_id=? AND publication_id=?'); $s->execute([user()['id'],$id]);
        if ($s->fetch()) { $s=db()->prepare('DELETE FROM gm_app.favorites WHERE user_id=? AND publication_id=?'); } else { $s=db()->prepare('INSERT INTO gm_app.favorites (user_id,publication_id) VALUES (?,?)'); } $s->execute([user()['id'],$id]); redirect('detail',['id'=>$id]);
    }
    if ($action==='save_publication') {
        require_staff(); $type=field('type',30); if (!isset(types()[$type]) || !role_allows($type)) throw new RuntimeException('Accès interdit.');
        $id=(int)($_POST['id']??0); $title=field('title',220); if (!$title) throw new RuntimeException('Le titre est obligatoire.');
        $status=field('status',20)==='published'?'published':'draft'; $scholarshipStatus=field('scholarship_status',20); if (!in_array($scholarshipStatus,['ouverte','fermee','a_venir'],true)) $scholarshipStatus='a_venir';
        $official=field('official_url',2048); if ($official && (!filter_var($official,FILTER_VALIDATE_URL) || !in_array(strtolower((string)parse_url($official,PHP_URL_SCHEME)),['http','https'],true))) throw new RuntimeException('Lien officiel invalide.');
        $date=function($name) { $v=field($name,10); if (!$v) return null; $d=DateTime::createFromFormat('!Y-m-d',$v); if (!$d || $d->format('Y-m-d')!==$v) throw new RuntimeException('Date invalide.'); return $v; };
        $verified=$date('verified_date'); if ($type==='temoignage' && $status==='published' && !$verified) throw new RuntimeException('Une date de validation est nécessaire pour publier un témoignage.');
        $values=[$type,$title,field('excerpt',5000),field('body',30000),field('country',120),field('level',120),field('domain',120),field('funding',190),field('nationality',190),field('category',120),$date('deadline'),$official,$verified,$status,$scholarshipStatus];
        if ($id) { $s=db()->prepare('SELECT type FROM gm_app.publications WHERE id=?'); $s->execute([$id]); $old=$s->fetchColumn(); if (!$old || !role_allows($old)) throw new RuntimeException('Accès interdit.'); $s=db()->prepare('UPDATE gm_app.publications SET type=?,title=?,excerpt=?,body=?,country=?,level=?,domain=?,funding=?,nationality=?,category=?,deadline=?,official_url=?,verified_date=?,status=?,scholarship_status=?, updated_at=NOW() WHERE id=?'); $values[]=$id; }
        else $s=db()->prepare('INSERT INTO gm_app.publications (type,title,excerpt,body,country,level,domain,funding,nationality,category,deadline,official_url,verified_date,status,scholarship_status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) RETURNING id');
        $s->execute($values); if (!$id) $id=(int)$s->fetchColumn(); audit('Publication enregistrée : '.$id); flash('Publication enregistrée.'); redirect('admin');
    }
    if ($action==='delete_publication') {
        require_staff(); $id=(int)($_POST['id']??0); $s=db()->prepare('SELECT type FROM gm_app.publications WHERE id=?'); $s->execute([$id]); $type=$s->fetchColumn(); if (!$type || !role_allows($type)) throw new RuntimeException('Accès interdit.');
        $s=db()->prepare('DELETE FROM gm_app.publications WHERE id=?'); $s->execute([$id]); audit('Publication supprimée : '.$id); flash('Publication supprimée.'); redirect('admin');
    }
} catch (Throwable $ex) {
    error_log('GLOBAL MENTORAT: '.$ex->getMessage());
    flash($ex instanceof RuntimeException && !($ex instanceof PDOException) ? $ex->getMessage() : 'Une erreur est survenue. Vérifiez la configuration ou réessayez.');
    $back=['inquiry'=>'contact','register'=>'inscription','login'=>'connexion','profile'=>'espace','save_publication'=>'admin','delete_publication'=>'admin','favorite'=>'bourses']; redirect($back[$action]??'accueil');
}
