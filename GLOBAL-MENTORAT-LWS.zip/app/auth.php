<?php
function auth_valid_tokens(array $data): bool {
    return !empty($data['access_token']) && is_string($data['access_token']) && !empty($data['refresh_token']) && is_string($data['refresh_token']);
}
function auth_verified_user(string $access): ?array {
    $result=auth_request('GET','user',null,$access);
    if ($result['status']===401 || $result['status']===403) return null;
    if ($result['status']!==200) throw new RuntimeException('Le service d’authentification est indisponible.');
    $u=$result['data'];
    if (empty($u['id']) || !is_string($u['id']) || !preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i',$u['id']) || empty($u['email_confirmed_at']) || !filter_var($u['email']??'',FILTER_VALIDATE_EMAIL)) return null;
    return $u;
}
function auth_create_local_user(array $identity): array {
    $name=trim((string)($identity['user_metadata']['full_name']??''));
    $name=mb_substr($name ?: 'Étudiant',0,120,'UTF-8');
    $email=strtolower((string)$identity['email']);
    $s=db()->prepare("INSERT INTO gm_app.users (auth_user_id,name,email,role) VALUES (?,?,?,'student') ON CONFLICT (auth_user_id) DO UPDATE SET email=EXCLUDED.email RETURNING id,name,email,role,auth_user_id");
    $s->execute([$identity['id'],$name,$email]);
    return $s->fetch();
}
function auth_login(string $email, string $password): array {
    $result=auth_request('POST','token?grant_type=password',['email'=>$email,'password'=>$password]);
    if ($result['status']===429) throw new RuntimeException('Trop de tentatives. Réessayez plus tard.');
    if ($result['status']>=500) throw new RuntimeException('Le service d’authentification est indisponible.');
    if ($result['status']!==200 || !auth_valid_tokens($result['data'])) throw new RuntimeException('Identifiants incorrects ou adresse e-mail non confirmée.');
    $identity=auth_verified_user($result['data']['access_token']);
    if (!$identity) throw new RuntimeException('Identifiants incorrects ou adresse e-mail non confirmée.');
    $local=auth_create_local_user($identity);
    session_regenerate_id(true);
    $_SESSION['auth']=['access_token'=>$result['data']['access_token'],'refresh_token'=>$result['data']['refresh_token'],'auth_user_id'=>$identity['id']];
    return $local;
}
function auth_session_identity(): ?array {
    if (empty($_SESSION['auth']['access_token']) || empty($_SESSION['auth']['refresh_token']) || empty($_SESSION['auth']['auth_user_id'])) return null;
    $identity=auth_verified_user($_SESSION['auth']['access_token']);
    if (!$identity) {
        $refresh=auth_request('POST','token?grant_type=refresh_token',['refresh_token'=>$_SESSION['auth']['refresh_token']]);
        if ($refresh['status']!==200 || !auth_valid_tokens($refresh['data'])) { unset($_SESSION['auth']); return null; }
        $_SESSION['auth']['access_token']=$refresh['data']['access_token'];
        $_SESSION['auth']['refresh_token']=$refresh['data']['refresh_token'];
        $identity=auth_verified_user($_SESSION['auth']['access_token']);
    }
    if (!$identity || !hash_equals($_SESSION['auth']['auth_user_id'],$identity['id'])) { unset($_SESSION['auth']); return null; }
    return $identity;
}
function auth_logout(): void {
    if (!empty($_SESSION['auth']['access_token'])) {
        try {
            if (auth_session_identity()) {
                $result=auth_request('POST','logout?scope=local',[],$_SESSION['auth']['access_token']);
                if ($result['status']<200 || $result['status']>=300) error_log('Supabase Auth : révocation distante refusée.');
            }
        } catch (Throwable $e) { error_log('Supabase Auth : révocation distante indisponible.'); }
    }
    $_SESSION=[];
    if (ini_get('session.use_cookies')) { $params=session_get_cookie_params(); setcookie(session_name(),'',time()-42000,$params['path'],$params['domain'],$params['secure'],$params['httponly']); }
    session_destroy();
}
