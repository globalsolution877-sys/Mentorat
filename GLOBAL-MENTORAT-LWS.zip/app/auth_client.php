<?php
/** Supabase Auth, appelé exclusivement côté serveur avec une clé publique. */
function auth_request(string $method, string $path, ?array $payload=null, ?string $token=null): array {
    global $config;
    $base=rtrim((string)($config['supabase_url']??''),'/');
    $key=(string)($config['supabase_publishable_key']??'');
    if (!$base || !$key || !preg_match('~^https://[a-z0-9-]+\.supabase\.co$~', $base) || !function_exists('curl_init')) throw new RuntimeException('Supabase Auth n’est pas configuré sur le serveur.');
    $headers=['apikey: '.$key, 'Content-Type: application/json'];
    if ($token!==null) $headers[]='Authorization: Bearer '.$token;
    $ch=curl_init($base.'/auth/v1/'.$path);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>15,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_FOLLOWLOCATION=>false,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    if ($payload!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($payload,JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR));
    $body=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE); curl_close($ch);
    if ($body===false || !$status) throw new RuntimeException('Le service d’authentification est indisponible.');
    $data=json_decode($body,true);
    return ['status'=>$status,'data'=>is_array($data)?$data:[]];
}
