<?php
try {
    $s=db()->prepare('SELECT * FROM gm_app.profiles WHERE user_id=?'); $s->execute([user()['id']]); $profile=$s->fetch() ?: [];
    $s=db()->prepare("SELECT p.* FROM gm_app.publications p JOIN gm_app.favorites f ON f.publication_id=p.id WHERE f.user_id=? AND p.status='published' ORDER BY p.created_at DESC"); $s->execute([user()['id']]); $favorites=$s->fetchAll();
} catch (Throwable $ex) { echo '<p>Le profil est momentanément indisponible.</p>'; return; }
?>
<p class="lead">Bonjour <?=e(user()['name'])?>.</p><p>Complétez votre profil et retrouvez les bourses enregistrées.</p><div class="actions"><a class="btn navy" href="<?=e(url('contact',['type'=>'orientation']))?>">Demander une orientation →</a><a class="btn border" href="<?=e(url('contact',['type'=>'rendezvous']))?>">Demander un rendez-vous</a></div>
<h2>Mon profil académique</h2><form class="form" method="post"><?php token(); ?><input type="hidden" name="action" value="profile"><?php foreach (['academic_profile'=>'Profil académique','diplomas'=>'Diplômes','results'=>'Résultats','interests'=>'Domaines d’intérêt'] as $key=>$label): ?><label><?=e($label)?><textarea name="<?=e($key)?>" maxlength="5000" rows="3"><?=e($profile[$key]??'')?></textarea></label><?php endforeach; ?><button class="btn navy">Enregistrer mon profil</button></form>
<h2>Mes bourses favorites</h2><?php cards($favorites); ?><form method="post" class="logout"><?php token(); ?><input type="hidden" name="action" value="logout"><button class="btn border">Se déconnecter</button></form>
