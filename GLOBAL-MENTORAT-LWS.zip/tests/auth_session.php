<?php
// Tests déterministes de la logique de session avec un transport Auth simulé.
$queue=[]; $calls=[];
function auth_request(string $method,string $path,?array $payload=null,?string $token=null): array {
    global $queue,$calls;
    $calls[]=[$method,$path,$payload,$token];
    if (!$queue) throw new RuntimeException('Réponse simulée manquante');
    return array_shift($queue);
}
require dirname(__DIR__).'/app/auth.php';
function ok($assertion,$message) { if (!$assertion) { fwrite(STDERR,"ÉCHEC : $message\n"); exit(1); } }
$id='5b3ec3a9-4bf3-4f69-b55d-c0a256fa19bf';
$identity=['id'=>$id,'email'=>'student@example.test','email_confirmed_at'=>'2026-01-01T00:00:00Z'];
$_SESSION=['auth'=>['access_token'=>'expired','refresh_token'=>'old-refresh','auth_user_id'=>$id]];
$queue=[['status'=>401,'data'=>[]],['status'=>200,'data'=>['access_token'=>'new','refresh_token'=>'new-refresh']],['status'=>200,'data'=>$identity]];
ok(auth_session_identity()['id']===$id,'renouvellement et vérification du sujet');
ok($_SESSION['auth']['refresh_token']==='new-refresh','rotation du refresh token');
ok($calls[1][1]==='token?grant_type=refresh_token','endpoint de renouvellement');
$_SESSION=['auth'=>['access_token'=>'valid','refresh_token'=>'r','auth_user_id'=>$id]];
$queue=[['status'=>200,'data'=>array_merge($identity,['id'=>'2b3ec3a9-4bf3-4f69-b55d-c0a256fa19bf'])]];
ok(auth_session_identity()===null && !isset($_SESSION['auth']),'refus de changement de sujet');
$_SESSION=['auth'=>['access_token'=>'expired','refresh_token'=>'bad','auth_user_id'=>$id]];
$queue=[['status'=>401,'data'=>[]],['status'=>400,'data'=>[]]];
ok(auth_session_identity()===null && !isset($_SESSION['auth']),'refus de refresh invalide');
$queue=[['status'=>200,'data'=>array_merge($identity,['email_confirmed_at'=>null])]];
ok(auth_verified_user('token')===null,'refus des e-mails non confirmés');
$queue=[['status'=>200,'data'=>array_merge($identity,['id'=>'not-a-uuid'])]];
ok(auth_verified_user('token')===null,'refus des identités malformées');
echo "Tests de session Auth : OK\n";
