# Installation PHP sur LWS avec Supabase

## Prérequis
PHP 7.4 ou plus récent maintenu, extensions `pdo_pgsql`, `curl` et `mbstring`, accès réseau sortant TCP et TLS depuis LWS vers Supabase, certificat HTTPS et accès SSH pour créer le premier administrateur. Un hébergement mutualisé MySQL classique n'offre pas nécessairement `pdo_pgsql` ni la connexion sortante : **faire confirmer ces points par LWS avant de choisir cette architecture**. Aucun serveur Node.js ni WordPress n'est nécessaire.

## Base Supabase

Le projet `global-mentorat` (`yhsppzxwmltbjntdqciy`) contient déjà le schéma privé `gm_app` et le rôle sans connexion `gm_app_runtime`. Les tables ont RLS activé et ne sont pas accessibles aux rôles `anon`, `authenticated` ou `service_role`. L'application PHP utilise une connexion PostgreSQL serveur pour les données et l'API Supabase Auth pour les comptes. Elle n'utilise pas Supabase Storage.

1. Pour ce projet, **ne pas réexécuter** `database/schema.sql`. Pour un autre projet vierge uniquement, l'appliquer avec un compte autorisé après vérification qu'il n'existe pas déjà un schéma ou un rôle de ce nom.
2. Créer par un canal sécurisé un **rôle PostgreSQL de connexion dédié** héritant de `gm_app_runtime`, sans `SUPERUSER`, `BYPASSRLS`, `CREATEDB` ou `CREATEROLE`. Définir un mot de passe fort sans le partager dans le chat ni le versionner. Par exemple, avec une connexion administrateur `psql`, créer le rôle puis utiliser `\password gm_portal_login` pour saisir le mot de passe sans l'écrire dans une requête enregistrée :
   ```sql
   CREATE ROLE gm_portal_login LOGIN INHERIT NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
   GRANT gm_app_runtime TO gm_portal_login;
   ```
   Vérifier que le compte Supabase utilisé a le droit de créer ce rôle et que le mode de connexion choisi accepte les rôles personnalisés. En cas de refus, demander l'aide de Supabase ; ne pas utiliser une clé service dans le navigateur ou désactiver RLS pour contourner le problème.
3. Dans Supabase, relever les paramètres de connexion PostgreSQL appropriés au rôle créé : hôte, port, base et nom d'utilisateur. Utiliser une connexion directe si l'hébergeur prend en charge IPv6 ; sinon, vérifier le pooler compatible IPv4 et les paramètres correspondant à un rôle personnalisé. Privilégier le mode session : le mode transaction peut nécessiter une configuration spécifique des requêtes préparées. Le certificat CA Supabase doit être disponible sur le serveur pour `sslmode=verify-full`. Ne pas désactiver la vérification TLS.

## Déploiement

1. Transférer le projet par SFTP. Configurer le domaine pour exposer **uniquement** le dossier `public/` ; `app/`, `database/`, `bin/` et `config.local.php` doivent rester hors de la racine web. Si LWS ne permet pas cette séparation, contacter l'hébergeur avant de continuer.
2. Copier `config.example.php` en `config.local.php` à la racine du projet, hors espace public. Renseigner les paramètres PostgreSQL, le chemin du certificat CA si nécessaire, l'URL Supabase et la clé **publishable** (ou `anon`) du projet ainsi que `base_path` (vide à la racine du domaine). Ne jamais utiliser la clé `service_role`/`secret` pour Auth, ni publier ou versionner la configuration.
3. Dans Supabase Auth, configurer la **Site URL** sur le domaine HTTPS réel du site et vérifier les URL de redirection autorisées et les modèles de confirmation. La configuration actuelle du projet pointe vers `http://localhost:3000` : elle n'est pas utilisable par les visiteurs. Vérifier l'envoi des e-mails et les limites du fournisseur SMTP Supabase ; configurer un SMTP adapté avant l'ouverture. Conserver la confirmation d'e-mail activée. Le lien de confirmation redirige vers le site ; l'utilisateur se connecte ensuite manuellement. Les jetons éventuellement ajoutés à l'URL par Supabase sont retirés de l'historique par le navigateur, sans connexion automatique.
4. Créer un compte avec le formulaire du site, confirmer son adresse e-mail puis se connecter une première fois. Depuis SSH, à la racine du projet, exécuter `php bin/create-admin.php` et indiquer l'adresse de ce compte pour le promouvoir. Le script ne crée plus de mot de passe et n'est pas accessible par le web. Si vous n'avez pas SSH, ne déployez pas d'installateur public non protégé.
5. Activer HTTPS, vérifier les connexions Auth HTTPS et PostgreSQL depuis LWS et tester inscription, confirmation, connexion, expiration/renouvellement, déconnexion, profil, publication, favoris et formulaires, ainsi que leurs permissions. Une page d'accueil vide ne prouve pas qu'une connexion est opérationnelle. Terminer les points du README et valider la politique de confidentialité avant ouverture.

## Sauvegarde
Sauvegarder la base PostgreSQL Supabase et les fichiers, y compris la configuration, de façon chiffrée hors serveur ; tester régulièrement les restaurations. Vérifier les options et limites de sauvegarde de votre offre Supabase. Aucune sauvegarde automatique n'est fournie par ce site.

## Comptes existants

La migration `database/migrations/20261115_supabase_auth.sql` est déjà appliquée au projet `global-mentorat`. Elle garde le champ historique `password_hash` mais le site ne l’utilise plus. Les comptes créés par l’ancien système ne sont pas automatiquement liés à Supabase Auth sur la seule base de l’e-mail : ne pas les associer sans validation d’identité. La base de ce projet était vide lors de la migration. Un autre projet existant nécessite une stratégie de migration et une sauvegarde préalable.
