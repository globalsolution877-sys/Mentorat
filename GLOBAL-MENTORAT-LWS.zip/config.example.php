<?php
// Copier en config.local.php hors de la racine web, puis renseigner les valeurs.
// Utiliser un compte PostgreSQL dédié à gm_app_runtime, jamais une clé API.
return [
    'db_host' => '', // hôte du pooler Supabase ou hôte direct
    'db_port' => 5432,
    'db_name' => 'postgres',
    'db_user' => '', // nom du rôle, format fourni par Supabase selon le mode de connexion
    'db_password' => '',
    // Facultatif si le certificat CA est déjà dans le magasin système libpq.
    'db_sslrootcert' => '',
    'supabase_url' => 'https://yhsppzxwmltbjntdqciy.supabase.co',
    'supabase_publishable_key' => '', // clé publishable ou anon uniquement, jamais service_role
    'base_path' => '',
];
