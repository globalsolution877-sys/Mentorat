-- Déjà appliquée au projet global-mentorat. À utiliser une seule fois pour
-- migrer une installation basée sur le précédent schéma PostgreSQL.
ALTER TABLE gm_app.users ADD COLUMN auth_user_id uuid UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE gm_app.users ALTER COLUMN password_hash DROP NOT NULL;
